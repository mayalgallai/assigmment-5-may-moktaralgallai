<?php 
$servername = "localhost";
$dbusername = "root"; 
$dbpassword = ""; 
$dbname = "expence_tracker";

