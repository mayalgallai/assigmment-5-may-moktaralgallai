<?php//--may moktar algallai 6/11/2023 
?>
<html>
    <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="../css/home.css">
       
    </head>
    <body>
        <div class="navbar">
            <div class="navbarcon">
                      <a href="home.html" id="navbarlogo"> EXPENSE TRUCKER </a>
                      <div class="navbartoggle" id="mobilemenu">
  </div>
  <ul class="navbarmenu">
      <li class="navbaritm">
          <input type="serch"  class="serch" placeholder="search" name="serch">
      </li>
            <li class="navbaritm"> 
                      <a href="" class="navbarlink" id="homepage">add category </a>
            </li>
            <li class="navbaritm"> 
                      <a href="#" class="navbarlink" id="aboutpage"> reports</a>
            </li>
            <li class="navbaritm"> 
                      <a href="aboutus.html" class="navbarlink" id="servicespage"> about us</a>
            </li>
            <li class="navbarbtn"> 

                      <a href="signup.php" class="button" id="signup">signup  </a>
            </li>
            <li class="navbarbtn"> 
                <a href="login.php" class="button" id="signup">login  </a>
      </li>
  </ul>
  </div>
</div> 
<main  class="main">
    <div class="image">
        <img src="../img/budget.png" alt="">
    </div>
    <div class="txt">
        <h1>WELCOME</h1>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>

    </div>

</main>

</main>
  </body>
  </html>